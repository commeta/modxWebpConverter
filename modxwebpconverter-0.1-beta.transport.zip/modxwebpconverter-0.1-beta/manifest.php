<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => ' * ModxWebpConverter plugin
 * https://github.com/commeta/modxWebpConverter
 * https://webdevops.ru/blog/webp-converter-plugin-modx.html
 * 
 * Copyright 2021 commeta <dcs-spb@ya.ru>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
',
    'readme' => '
modxWebpConverter, руководство - Webp конвертер для MODX Revo https://webdevops.ru/blog/webp-converter-plugin-modx.html
MODX Revolution плагин, который осуществляет конвертацию графических файлов в формат webp. 

## Установка:

1. Создаем подкаталог /connectors/converter/ и заливаем туда файлы:
* converter.php - Серверное api
* converter.js - Скрипт для админки
* Binaries - Бинарники утилиты cwebp, там есть для linux, windows, macos, freebsd, solaris.

Бинарники взяты с https://github.com/rosell-dk/webp-convert и https://developers.google.com/speed/webp/docs/precompiled

Установка & Обновление бинарников утилиты CWEBP https://github.com/commeta/modxWebpConverter/blob/master/Binaries/README.md

2. Создаем в админке плагин: modx_plugin_webp_converter.php и вешаем на события 
* OnManagerPageBeforeRender
* OnWebPagePrerender
* OnSiteRefresh 
* OnTemplateSave 
* OnChunkSave 
* OnPluginSave 
* OnSnippetSave
* OnTemplateVarSave
* OnDocFormSave

После чего в правом верхнем меню появится значок, по клику запустится в фоне сканирование каталогов сайта, и будет создана копия каждой картинки в подкаталоге webp. 
т.е. /assets/logo.png -> /webp/assets/logo.png.webp

3. После конвертирования всех найденых изображений, все картинки в HTML коде сайта будут заменены на webp, если браузер их поддерживает.


## Рузультаты тестирования

Протестировал на MODX Revolution 2.7.3-pl!
* Windows 7 64bit XAMPP PHP 7.4.9, 
* linux Ubuntu 20.04 64bit LAMP PHP 7.4.3, 
* linux CentOS 7 LANMP PHP 5.4.45

Взял солянку jpg & png, 24382 файлов, 3385MB.

Все отработало нормально, потребление памяти в пике: на win 6 580 936b, на lin 3 816 368b.
Сканирование подкаталогов заняло: 191ms SSD, 3123ms HDD.
Сжатие одного файла занимает от 28ms до 5800ms.
Результирующий объем пережатых файлов: 1005MB, потери в качестве не заметил.

Открыл одновременно 12 вкладок в браузере, в результате кодировка пошла в 12 потоков, у меня на Ryzen 5 2600X Six-Core обработка всех файлов заняла около 45 минут.
',
    'changelog' => '# Changelog

## Beta release [v0.1] (2020-08-25)
### 2021-01-04 Bug fix: Unsupported color conversion request, for YCCK JPGs. Error in cwebp tool, use PHP GD if webp supported
### 2021-01-07 Bug fix: add events log, show in modal window
### 2021-02-10 Bug fix: bin file error (139) in cwebp - segmentation fault. Use PHP GD if version >= 2.2.5
### 2021-02-10 Bug fix: bin file error (139) in cwebp - segmentation violation. If os Linux and cwebp installed, use cwebp in system path /usr/bin/cwebp 
### 2021-11-03 Bug fix: If os Linux and cwebp installed, use cwebp in system path /usr/bin/cwebp or /usr/local/bin/cwebp
### 2021-11-06 Add feature: Autostart search and convert new files, when cleaning cache

## Alfa release [v0.1] (2020-08-15)
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '38ffb257e57d3b8eb3b9a5ed3ab877e4',
      'native_key' => 'modxwebpconverter',
      'filename' => 'modNamespace/149409e18b8ac3b2e7711e21396dbd85.vehicle',
      'namespace' => 'modxwebpconverter',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '14851e30b832270fe3f1099015a19442',
      'native_key' => 5,
      'filename' => 'modPlugin/471fcb120ab2996499221930b4ff7e81.vehicle',
      'namespace' => 'modxwebpconverter',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c094b21f8eb6d089dad51a69484f57a1',
      'native_key' => 1,
      'filename' => 'modCategory/5170b9654ec232c24bdc2877821cf260.vehicle',
      'namespace' => 'modxwebpconverter',
    ),
  ),
);